
package model;//classe chave

public interface ICadastro {
    void cadastrar();
    void listar();
    void atualizar();
    void remover();
}
